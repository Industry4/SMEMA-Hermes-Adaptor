﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Htmltemplater
{
    class PageProperties
    {
        public string Folder { get; internal set; }
        public string HomeThumbnail { get; internal set; }
        public string Image1 { get; internal set; }
        public string Image2 { get; internal set; }
        public string Image3 { get; internal set; }
        public string Image4 { get; internal set; }
        public string Social { get; internal set; }
        public string Vendor { get; internal set; }
    }
}
