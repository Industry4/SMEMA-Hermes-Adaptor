﻿using System.IO;

namespace Htmltemplater
{
    class Program
    {
        static void Main(string[] args)
        {
            PageProperties[] Pages =
            {
                new PageProperties {
                    Folder = "asmpt",
                    Vendor = "ASMPT",
                    Image1 = "asmpt-hermes-standard-ready.jpg",
                    Image2 = "asmpt-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "asmpt-hermes-data-manipulation.jpg",
                    Image4 = "works-with-asmpt-smt.jpg",
                    Social = "works-with-asmpt-smt-social.jpg",
                    HomeThumbnail = "asmpt-thumbnail.png"
            },
                new PageProperties {
                    Folder = "europlacer",
                    Vendor = "Europlacer",
                    Image1 = "europlacer-hermes-standard-ready.jpg",
                    Image2 = "europlacer-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "europlacer-hermes-data-manipulation.jpg",
                    Image4 = "works-with-europlacer-smt.jpg",
                    Social = "works-with-europlacer-smt-social.jpg",
                    HomeThumbnail = "europlacer-thumbnail.png"
            },
                new PageProperties {
                    Folder = "mycronic",
                    Vendor = "Mycronic",
                    Image1 = "mycronic-hermes-standard-ready.jpg",
                    Image2 = "mycronic-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "mycronic-hermes-data-manipulation.jpg",
                    Image4 = "works-with-mycronic-smt.jpg",
                    Social = "works-with-mycronic-smt-social.jpg",
                    HomeThumbnail = "mycronic-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "fuji",
                    Vendor = "FUJI",
                    Image1 = "fuji-hermes-standard-ready.jpg",
                    Image2 = "fuji-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "fuji-hermes-data-manipulation.jpg",
                    Image4 = "works-with-fuji-smt.jpg",
                    Social = "works-with-fuji-smt-social.jpg",
                    HomeThumbnail = "fuji-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "yamaha",
                    Vendor = "YAMAHA",
                    Image1 = "yamaha-hermes-standard-ready.jpg",
                    Image2 = "yamaha-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "yamaha-hermes-data-manipulation.jpg",
                    Image4 = "works-with-yamaha-smt.jpg",
                    Social = "works-with-yamaha-smt-social.jpg",
                    HomeThumbnail = "yamaha-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "asys-group",
                    Vendor = "ASYS Group",
                    Image1 = "asys-group-hermes-standard-ready.jpg",
                    Image2 = "asys-group-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "asys-group-hermes-data-manipulation.jpg",
                    Image4 = "works-with-asys-group-smt.jpg",
                    Social = "works-with-asys-group-smt-social.jpg",
                    HomeThumbnail = "asys-group-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "juki",
                    Vendor = "JUKI",
                    Image1 = "juki-hermes-standard-ready.jpg",
                    Image2 = "juki-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "juki-hermes-data-manipulation.jpg",
                    Image4 = "works-with-juki-smt.jpg",
                    Social = "works-with-juki-smt-social.jpg",
                    HomeThumbnail = "juki-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "kurtz-ersa",
                    Vendor = "Kurtz Ersa",
                    Image1 = "kurtz-ersa-hermes-standard-ready.jpg",
                    Image2 = "kurtz-ersa-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "kurtz-ersa-hermes-data-manipulation.jpg",
                    Image4 = "works-with-kurtz-ersa-smt.jpg",
                    Social = "works-with-kurtz-ersa-smt-social.jpg",
                    HomeThumbnail = "kurtz-ersa-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "yj-link",
                    Vendor = "YJ LINK",
                    Image1 = "yj-link-hermes-standard-ready.jpg",
                    Image2 = "yj-link-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "yj-link-hermes-data-manipulation.jpg",
                    Image4 = "works-with-yj-link-smt.jpg",
                    Social = "works-with-yj-link-smt-social.jpg",
                    HomeThumbnail = "yj-link-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "electro-design",
                    Vendor = "Electro Design AB",
                    Image1 = "electro-design-hermes-standard-ready.jpg",
                    Image2 = "electro-design-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "electro-design-hermes-data-manipulation.jpg",
                    Image4 = "works-with-electro-design-smt.jpg",
                    Social = "works-with-electro-design-smt-social.jpg",
                    HomeThumbnail = "electro-design-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "vanstron",
                    Vendor = "Vanstron",
                    Image1 = "vanstron-hermes-standard-ready.jpg",
                    Image2 = "vanstron-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "vanstron-hermes-data-manipulation.jpg",
                    Image4 = "works-with-vanstron-smt.jpg",
                    Social = "works-with-vanstron-smt-social.jpg",
                    HomeThumbnail = "vanstron-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "simplimatic",
                    Vendor = "Simplimatic",
                    Image1 = "simplimatic-hermes-standard-ready.jpg",
                    Image2 = "simplimatic-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "simplimatic-hermes-data-manipulation.jpg",
                    Image4 = "works-with-simplimatic-smt.jpg",
                    Social = "works-with-simplimatic-smt-social.jpg",
                    HomeThumbnail = "simplimatic-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "flexlink",
                    Vendor = "FLEXLINK",
                    Image1 = "flexlink-hermes-standard-ready.jpg",
                    Image2 = "flexlink-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "flexlink-hermes-data-manipulation.jpg",
                    Image4 = "works-with-flexlink-smt.jpg",
                    Social = "works-with-flexlink-smt-social.jpg",
                    HomeThumbnail = "flexlink-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "kulicke-soffa",
                    Vendor = "Kulicke &amp; Soffa",
                    Image1 = "kulicke-soffa-hermes-standard-ready.jpg",
                    Image2 = "kulicke-soffa-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "kulicke-soffa-hermes-data-manipulation.jpg",
                    Image4 = "works-with-kulicke-soffa-smt.jpg",
                    Social = "works-with-kulicke-soffa-smt-social.jpg",
                    HomeThumbnail = "kulicke-soffa-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "panasonic-connect",
                    Vendor = "Panasonic Connect",
                    Image1 = "panasonic-connect-hermes-standard-ready.jpg",
                    Image2 = "panasonic-connect-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "panasonic-connect-hermes-data-manipulation.jpg",
                    Image4 = "works-with-panasonic-connect-smt.jpg",
                    Social = "works-with-panasonic-connect-smt-social.jpg",
                    HomeThumbnail = "panasonic-connect-thumbnail.png"
            },
                new PageProperties
                {
                    Folder = "nutek",
                    Vendor = "NUTEK",
                    Image1 = "nutek-hermes-standard-ready.jpg",
                    Image2 = "nutek-unsupported-ipc-hermes-9852.jpg",
                    Image3 = "nutek-hermes-data-manipulation.jpg",
                    Image4 = "works-with-nutek-smt.jpg",
                    Social = "works-with-nutek-smt-social.jpg",
                    HomeThumbnail = "nutek-thumbnail.png"
                }
            };

            foreach (var Page in Pages)
            {
                var html = File.ReadAllText("vendor-upgrade.html");

                html = html.Replace("{{{vendor}}}", Page.Vendor);
                html = html.Replace("{{{image1}}}", Page.Image1);
                html = html.Replace("{{{image2}}}", Page.Image2);
                html = html.Replace("{{{image3}}}", Page.Image3);
                html = html.Replace("{{{image4}}}", Page.Image4);
                html = html.Replace("{{{social}}}", Page.Social);

                var root = Directory.GetParent(Directory.GetCurrentDirectory()).FullName;

                var home = Path.Combine(root, Page.Folder);

                if ( Directory.Exists(home))
                {
                    Directory.Delete(home, true);
                }

                Directory.CreateDirectory(home);

                File.WriteAllText(Path.Combine(home, "index.html"), html );

                File.Copy(Page.Image1, Path.Combine(home, Page.Image1), true);
                File.Copy(Page.Image2, Path.Combine(home, Page.Image2), true);
                File.Copy(Page.Image3, Path.Combine(home, Page.Image3), true);
                File.Copy(Page.Image4, Path.Combine(home, Page.Image4), true);
                File.Copy(Page.Social, Path.Combine(home, Page.Social), true);
                File.Copy(Page.HomeThumbnail, Path.Combine(home, Page.HomeThumbnail), true);
            }


        }
    }
}
